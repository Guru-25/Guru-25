import java.util.HashMap;
import java.util.Scanner;

// Represents a device on the network
class Device {
    private String ipAddress;
    private String macAddress;

    public Device(String ipAddress, String macAddress) {
        this.ipAddress = ipAddress;
        this.macAddress = macAddress;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public String getMacAddress() {
        return macAddress;
    }
}

// Represents a network with devices and RARP cache
class Network {
    private HashMap<String, Device> rarpCache;

    public Network() {
        rarpCache = new HashMap<>();
    }

    // Add a device to the network
    public void addDevice(Device device) {
        rarpCache.put(device.getMacAddress(), device);
    }

    // Simulate RARP request
    public String rarpRequest(String macAddress) {
        Device device = rarpCache.get(macAddress);
        if (device != null) {
            return "IP Address for " + macAddress + ": " + device.getIpAddress();
        } else {
            return "IP address not found for MAC address " + macAddress;
        }
    }
}

public class RARP_Simulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Create network
        Network network = new Network();
        // Get user input for number of devices
        System.out.println("Enter the number of devices:");
        int numDevices = Integer.parseInt(scanner.nextLine());
        // Get user input for devices
        for (int i = 0; i < numDevices; i++) {
            System.out.println("Enter IP address and MAC address for device " + (i + 1) + " (separated by space):");
            String[] input = scanner.nextLine().trim().split("\\s+");
            Device device = new Device(input[0], input[1]);
            network.addDevice(device);
        }
        // Simulate RARP requests
        System.out.println("Enter MAC address to look up IP address:");
        String macAddress = scanner.nextLine();
        System.out.println(network.rarpRequest(macAddress));
        scanner.close();
    }
}
