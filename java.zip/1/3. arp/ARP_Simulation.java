import java.util.HashMap;
import java.util.Scanner;
// Represents a device on the network
class Device {
    private String ipAddress;
    private String macAddress;
    public Device(String ipAddress, String macAddress) {
        this.ipAddress = ipAddress;
        this.macAddress = macAddress;
    }
    public String getIpAddress() {
        return ipAddress;
    }
    public String getMacAddress() {
        return macAddress;
    }
}
// Represents a network with devices and ARP cache
class Network {
    private HashMap<String, Device> arpCache;
    public Network() {
        arpCache = new HashMap<>();
    }
    // Add a device to the network
    public void addDevice(Device device) {
        arpCache.put(device.getIpAddress(), device);
    }
    // Simulate ARP request
    public String arpRequest(String ipAddress) {
        Device device = arpCache.get(ipAddress);
        if (device != null) {
            return "MAC Address for " + ipAddress + ": " + device.getMacAddress();
        }
        else {
            return "MAC address not found for IP address " + ipAddress;
        }
    } 
}



public class ARP_Simulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // Create network
        Network network = new Network();
        // Get user input for number of devices
        System.out.println("Enter the number of devices:");
        int numDevices = Integer.parseInt(scanner.nextLine());
        // Get user input for devices
        for (int i = 0; i < numDevices; i++) {
            System.out.println("Enter IP address and MAC address for device " + (i + 1) + " (separated by space):");
            String[] input = scanner.nextLine().trim().split("\\s+");
            Device device = new Device(input[0], input[1]);
            network.addDevice(device);
        }
        // Simulate ARP requests
        System.out.println("Enter IP address to look up MAC address:");
        String ipAddress = scanner.nextLine();
        System.out.println(network.arpRequest(ipAddress));
        scanner.close();
    }
}
