import java.io.*;
import java.net.*;
public class ARPServer {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(5000);
            System.out.println("Server listening for ARP requests...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                String ip= in.readLine();
                System.out.println("Received ARP request for IP address: " + ip);
                String mac= generateMACAddress(ip);
                out.println(mac);
                clientSocket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static String generateMACAddress(String ip){
        int hc = ip.hashCode();
        String macAddress = String.format("%02X:%02X:%02X:%02X:%02X:%02X",
        (hc >> 40) & 0xFF,
        (hc >> 32) & 0xFF,
        (hc >> 24) & 0xFF,
        (hc >> 16) & 0xFF,
        (hc >> 8) & 0xFF,
        hc & 0xFF);
        return macAddress;
    }
}