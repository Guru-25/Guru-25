import java.io.*;
import java.net.*;

public class RARPServer {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(5000);
            System.out.println("Server listening for RARP requests...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                String mac = in.readLine();
                System.out.println("Received RARP request for MAC address: " + mac);
                String ip= generateIPAddress(mac);
                out.println(ip);
                clientSocket.close();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static String generateIPAddress(String macAddress) {
        long macInteger = Long.parseLong(macAddress.replaceAll(":", ""), 16);
        String ipAddress = String.format("%d.%d.%d.%d",
        (macInteger >> 40) & 0xFF,
        (macInteger >> 32) & 0xFF,
        (macInteger >> 24) & 0xFF,
        macInteger & 0xFF);
        return ipAddress;
    }
} 