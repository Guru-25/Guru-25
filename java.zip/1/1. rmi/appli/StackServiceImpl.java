import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject; import java.util.Stack;
public	class	StackServiceImpl	extends	UnicastRemoteObject	implements stackservice {
private char[] stackArray; private int top;
private int maxSize;
protected StackServiceImpl(int maxSize) throws RemoteException { super();
this.maxSize = maxSize; this.stackArray = new char[maxSize]; this.top = -1;
}
@Override
public void push(char c) throws RemoteException {

if (top < maxSize - 1) { top++; stackArray[top] = c;
} else {
throw new RemoteException("Stack overflow");
}
}
@Override
public char pop() throws RemoteException { if (top >= 0) {
char c = stackArray[top]; top--;
return c;
} else {
throw new RemoteException("Stack underflow");
}
}
@Override
public boolean isPalindrome(String str) {
StringBuilder strippedStr = new StringBuilder(str.replaceAll("[^a-zA-Z0-9]", "").toLowerCase());
// Create a stack to store characters Stack<Character> stack = new Stack<>();
// Push characters onto the stack
for (char c : strippedStr.toString().toCharArray()) { stack.push(c);
}



// Pop characters and compare with original string StringBuilder reversedStr = new StringBuilder(); while (!stack.isEmpty()) {
reversedStr.append(stack.pop());
}
// Compare reversed string with original string
return strippedStr.toString().equals(reversedStr.toString());
}
}
