import java.rmi.Remote;
import java.rmi.RemoteException; interface stackservice extends Remote{
void push(char c) throws RemoteException; char pop() throws RemoteException;
boolean isPalindrome(String str) throws RemoteException;
}
