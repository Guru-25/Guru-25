import java.rmi.*;
import java.rmi.registry.*; public class Myservers {
public static void main(String args[]) { try {
// Create an instance of StackServiceImpl with a specified maxSize int maxSize = 100; // Or any desired value
StackServiceImpl ss = new StackServiceImpl(maxSize);
// Register the stack service with RMI registry Naming.rebind("rmi://localhost:3800/guru", ss); System.out.println("StackServer is ready.");
} catch (Exception e) {
System.err.println("StackServer exception: " + e.toString()); e.printStackTrace();
}}}
