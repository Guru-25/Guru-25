import java.rmi.*; import java.util.Scanner; public class MyClients {
public static void main(String args[]) { try {
stackservice ss = (stackservice) Naming.lookup("rmi://localhost:3800/kesho"); Scanner scanner = new Scanner(System.in);
System.out.print("Enter a string to check if it's a palindrome: "); String userInput = scanner.nextLine();
boolean isPalindrome = ss.isPalindrome(userInput);
System.out.println("Is \"" + userInput + "\" a palindrome? " + isPalindrome); scanner.close();
} catch (Exception e) {
System.err.println("StackClient exception: " + e.toString()); e.printStackTrace();
}
}
}
