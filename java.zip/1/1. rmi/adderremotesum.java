//arraysumadderRemote
import java.rmi.*;
import java.rmi.server.*;

public class adderremotesum extends UnicastRemoteObject implements addersum{
    adderremotesum() throws RemoteException{
        super();
    }
    public int [] sum(int x[],int n){
        int[] z= new int[n];
        for (int i=0;i<n;i++){
            z[i]=x[i]*x[i];
        }
        return z;
    }
}
