//addersumclient
import java.rmi.*;
import java.util.Scanner;

class addersumclient{
    public static void main(String args[]){
        try{
            Scanner in=new Scanner(System.in);
            System.out.println("Enter the number of elements in the array");
            int n= in.nextInt();
            int x[]= new int[n];
            System.out.println("Enter the elements");
            for (int i=0;i<n;i++){
                x[i]=in.nextInt();
            }
            addersum stub= (addersum)Naming.lookup("rmi://localhost:5000/sonoo");
            int z[]=new int[n];
            z=stub.sum(x,n);
            for(int i=0;i<n;i++){
                System.out.println(z[i]);
            }
        }
        catch(Exception e){
        }
    }
}
 
