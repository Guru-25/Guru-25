//arraysumadder
import java.rmi.*;

public interface addersum extends Remote{
    public int[] sum(int x[], int n) throws RemoteException;
}
