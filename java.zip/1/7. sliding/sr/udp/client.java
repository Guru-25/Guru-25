import java.util.*;
import java.net.*;
import java.io.*;
public class ClientSW3 {
    public static void main(String args[]) {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            int port = 12345;
            InetAddress serverAddress = InetAddress.getByName("localhost");
            Scanner ob = new Scanner(System.in);
            System.out.println("Enter the amount of data to be sent:");
            int n = ob.nextInt();
            byte[] sdata;
            byte[] rdata = new byte[1000];
            DatagramPacket receivePacket = new DatagramPacket(rdata, rdata.length);
            sdata = Integer.toString(n).getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sdata, sdata.length, serverAddress, port);
            socket.send(sendPacket);
            int[] a = new int[n];
            for (int i = 0; i < n; i++) {
                socket.receive(receivePacket);
                String receivedData = new String(receivePacket.getData(), 0, receivePacket.getLength());
                String[] parts = receivedData.split(" "); // Splitting sequence number and packet data
                int seqNum = Integer.parseInt(parts[0]);
                a[seqNum] = Integer.parseInt(parts[1]);
            }
            System.out.println("Enter the index of the bit to be corrected (0 to " + (n - 1) + "):");
            int k = ob.nextInt();
            a[k] = -1; // Simulating an error
            System.out.println("Received Data:");
            for (int i = 0; i < n; i++) {
                System.out.println(a[i]);
            }

            sdata = Integer.toString(k).getBytes();
            sendPacket = new DatagramPacket(sdata, sdata.length, serverAddress, port);
            socket.send(sendPacket);

            System.out.println("Sent correction for bit " + k);
            
            socket.receive(receivePacket);
            String correctedData = new String(receivePacket.getData(), 0, receivePacket.getLength());
            String[] parts = correctedData.split(" "); // Splitting sequence number and corrected packet data
            int seqNum = Integer.parseInt(parts[0]);
            a[seqNum] = Integer.parseInt(parts[1]);
            System.out.println("After Correction:");
            for (int i = 0; i < n; i++) {
                System.out.println(a[i]);
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (socket != null) {
                socket.close();
            }
        }
    }
}