import java.util.*;
import java.net.*;
import java.io.*;
public class ServerSW3 {
    public static void main(String args[]) {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket(12345);
            byte[] rdata = new byte[1000];
            DatagramPacket receivePacket = new DatagramPacket(rdata, rdata.length);
            socket.receive(receivePacket);
            int n = Integer.parseInt(new String(receivePacket.getData(), 0, receivePacket.getLength()));
            InetAddress clientAddress = receivePacket.getAddress();
            int port = receivePacket.getPort();
            System.out.println("Enter the data to be sent:");
            Scanner ob = new Scanner(System.in);
            int[] a = new int[n];
            for (int i = 0; i < n; i++) {
                a[i] = ob.nextInt();
            }
            System.out.println("Sending Data");
            for (int i = 0; i < n; i++) {
                String data = Integer.toString(i) + " " + Integer.toString(a[i]); // Adding sequence number to each
                byte[] sdata = data.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sdata, sdata.length, clientAddress, port);
                socket.send(sendPacket);
            }
            int k;
            socket.receive(receivePacket);
            k = Integer.parseInt(new String(receivePacket.getData(), 0, receivePacket.getLength()));
            System.out.println("There is an error in " + k + ", resending data");
            String data = Integer.toString(k) + " " + Integer.toString(a[k]); // Adding sequence number to the resent packet
            byte[] sdata = data.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sdata, sdata.length, clientAddress, port);
            socket.send(sendPacket);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (socket != null) {
            socket.close();}
        }
    }
}
