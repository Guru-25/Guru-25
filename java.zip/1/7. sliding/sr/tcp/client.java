import java.io.*;
import java.net.*;
import java.util.*;

public class ClientSW1 {
    public static void main(String args[]) {
        Socket socket = null;
        DataInputStream dis = null;
        DataOutputStream dos = null;
        try {
            InetAddress adr = InetAddress.getByName("localhost");
            socket = new Socket(adr, 12345);
            dis = new DataInputStream(socket.getInputStream());
            dos = new DataOutputStream(socket.getOutputStream());
            Scanner ob = new Scanner(System.in);
            System.out.println("Enter the amount of data to be sent:");
            int n = ob.nextInt();
            dos.writeInt(n); // Send number of packets
            dos.flush();
            int[] data = new int[n];
            System.out.println("Enter the data to be sent:");
            for (int i = 0; i < n; i++) {
                data[i] = ob.nextInt();
                dos.writeInt(data[i]); // Send packet data
                dos.flush();
            }
            System.out.println("Enter the index of the errored bit:");
            int errorIndex = ob.nextInt();
            dos.writeInt(errorIndex); // Send index of errored packet
            dos.flush();
            // Receive corrected data
            int correctedData = dis.readInt();
            System.out.println("Corrected data at index " + errorIndex + ": " + correctedData);
        }
        catch (IOException e) {
            System.out.println(e);
        }
        finally {
            try {
                if (dis != null) dis.close();
                if (dos != null) dos.close();
                if (socket != null) socket.close();
            }
            catch (IOException e) {
                System.out.println(e);
            }
        }
    }
}