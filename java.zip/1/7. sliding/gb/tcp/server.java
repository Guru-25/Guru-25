import java.io.*;
import java.net.*;

public class ServerSW2 {
    public static void main(String args[]) {
        ServerSocket server = null;
        Socket client = null;
        DataInputStream dis = null;
        DataOutputStream dos = null;
        try {
            server = new ServerSocket(12345);
            client = server.accept();
            dis = new DataInputStream(client.getInputStream());
            dos = new DataOutputStream(client.getOutputStream());
            int n = dis.readInt(); // Number of packets
            System.out.println("Enter the data to be sent");
            int[] data = new int[n];
            for (int i = 0; i < n; i++) {
                data[i] = dis.readInt(); // Receive packet dat
            }
                int lostPacketIndex = dis.readInt(); // Receive index of lost packet
                System.out.println("This data has been lost: " + data[lostPacketIndex] + ". Resending data...");
                // Retransmit the lost packet and subsequent packets
                for (int i = lostPacketIndex; i < n; i++) {
                    dos.writeInt(data[i]);
                    dos.flush();
                    System.out.println("Resent data: " + data[i]); // Debug print statement}
                }
                catch (IOException e) {
                    System.out.println(e);
                }
                finally {
                    try {
                        if (dis != null) dis.close();
                        if (dos != null) dos.close();
                        if (client != null) client.close();
                        if (server != null) server.close();
                    }
                    catch (IOException e) {
                        System.out.println(e);
                    }
                }
            }
        }
    }