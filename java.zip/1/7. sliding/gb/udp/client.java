import java.util.*;
import java.net.*;
import java.io.*;
public class ClientSW4 {
    public static void main(String args[]) {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            int port = 12345;
            InetAddress serverAddress = InetAddress.getByName("localhost");
            Scanner ob = new Scanner(System.in);
            System.out.println("Enter the amount of data to be sent:");
            int n = ob.nextInt();
            byte[] sdata;
            byte[] rdata = new byte[1000];
            sdata = Integer.toString(n).getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sdata, sdata.length, serverAddress, port);
            socket.send(sendPacket);
            DatagramPacket receivePacket = new DatagramPacket(rdata, rdata.length);
            int[] a = new int[n];
            for (int i = 0; i < n; i++) {
                socket.receive(receivePacket);
                a[i] = Integer.parseInt(new String(receivePacket.getData(), 0, receivePacket.getLength()));
            }
            System.out.println("Enter the index of the bit to be corrected (0 to " + (n - 1) + "):");
            int k = ob.nextInt();
            for (int i = k; i < n; i++) {
                a[i] = -1; // Simulating an error
            }
                System.out.println("Received Data:");
                for (int i = 0; i < n; i++) {
                    System.out.println(a[i]);
                }
                sdata = Integer.toString(k).getBytes();
                sendPacket = new DatagramPacket(sdata, sdata.length, serverAddress, port);
                socket.send(sendPacket);
                System.out.println("Sent correction for bit " + k);
                for (int i = k; i < n; i++) {
                    socket.receive(receivePacket);
                    a[i] = Integer.parseInt(new String(receivePacket.getData(), 0, receivePacket.getLength()));
                }
                System.out.println("After Correction:");
                for (int i = 0; i < n; i++) {
                    System.out.println(a[i]);
                }
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                if (socket != null) {
                socket.close();}
            }
        }
    }