import java.io.*;
import java.net.*;

class SummationServer {

    public static void main(String[] args) {

        try {
            int serverPort = Integer.parseInt(args[0]);

            // Creating a DatagramSocket for UDP communication
            DatagramSocket socket = new DatagramSocket(serverPort);

            while (true) {
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);

                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();
                String clientMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                int count = Integer.parseInt(clientMessage);

                // Creating and starting a new thread for handling client request
                Thread thread = new SummationThread(socket, clientAddress, clientPort, count);
                thread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}