import java.net.*;
class SummationServer {
    public static void main(String[] args) {
        try {
    int serverPort = Integer.parseInt(args[0]);
    DatagramSocket socket = new DatagramSocket(serverPort);
            while (true) {
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                socket.receive(receivePacket);
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();
                String clientMessage = new String(receivePacket.getData(), 0, receivePacket.getLength());
                int count = Integer.parseInt(clientMessage);
                Thread thread = new SummationThread(socket, clientAddress, clientPort, count);
                thread.start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
class SummationThread extends Thread {
    private DatagramSocket socket;
    private InetAddress clientAddress;
    private int clientPort;
    private int count;
    public SummationThread(DatagramSocket socket, InetAddress clientAddress, int clientPort, int count) {
        this.socket = socket;
        this.clientAddress = clientAddress;
        this.clientPort = clientPort;
        this.count = count;    }
    
        public void run() {
            try {
                int sum = 0;
                for (int ctr = 1; ctr <= count; ctr++) {
                    sum += ctr;
                    Thread.sleep(200);
                }
                String sumString = Integer.toString(sum);
                byte[] sendData = sumString.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
                socket.send(sendPacket);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
