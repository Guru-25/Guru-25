import java.net.*;
public class SummationClient {
    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("Usage: java SummationClient <host> <port> <number>");
            return;
        }


        String host = args[0];
        int port = Integer.parseInt(args[1]);
        int number = Integer.parseInt(args[2]);


        try {
            InetAddress serverAddress = InetAddress.getByName(host);
            DatagramSocket socket = new DatagramSocket();
            // Send request to the server
            byte[] sendData = Integer.toString(number).getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, port);
            socket.send(sendPacket);
            // Receive response from the server
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            socket.receive(receivePacket);
            // Process the response
            String response = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println("Sum from server: " + response);
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
