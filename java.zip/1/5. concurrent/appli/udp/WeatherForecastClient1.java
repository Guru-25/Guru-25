import java.io.*;
import java.net.*;


public class WeatherForecastClient1 {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java WeatherForecastClient <server_hostname> <server_port>");
            return;
        }


        String serverHostname = args[0];
        int serverPort = Integer.parseInt(args[1]);


        try {
            DatagramSocket clientSocket = new DatagramSocket(); // Create UDP socket


            // Create input stream reader for user input
            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));


            // Prompt user to enter city and ZIP code
            System.out.print("Enter a city: ");
            String city = inFromUser.readLine();
            System.out.print("Enter ZIP code: ");
            String zipCode = inFromUser.readLine();


            // Construct message to send
            String message = city + "," + zipCode;
            byte[] sendData = message.getBytes();


            // Send message to server
            InetAddress serverAddress = InetAddress.getByName(serverHostname);
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
            clientSocket.send(sendPacket);


            // Receive response from server
            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            clientSocket.receive(receivePacket);


            // Process response
            String weatherForecast = new String(receivePacket.getData(), 0, receivePacket.getLength());
            System.out.println("Weather Forecast: " + weatherForecast);


            // Close socket
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
