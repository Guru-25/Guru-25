import java.io.*;
import java.net.*;
import java.util.*;


public class WeatherForecastServer1 {
    private static final Map<String, String[]> weatherData = new HashMap<>();


    static {
        weatherData.put("New York", new String[]{"Sunny", "Partly Cloudy", "Rainy", "Thunderstorms"});
        weatherData.put("Los Angeles", new String[]{"Sunny", "Clear", "Foggy", "Cloudy"});
        weatherData.put("Chicago", new String[]{"Snowy", "Cloudy", "Windy", "Partly Cloudy"});
        weatherData.put("Miami", new String[]{"Rainy", "Thunderstorms", "Partly Sunny", "Cloudy"});
    }


    public static void main(String[] args) {
        try {
            DatagramSocket serverSocket = new DatagramSocket(9876); // Port for communication


            System.out.println("Weather Forecast Server is running...");


            while (true) {
                byte[] receiveData = new byte[1024];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
                serverSocket.receive(receivePacket); // Receive client request


                String cityAndZip = new String(receivePacket.getData(), 0, receivePacket.getLength());
                String[] cityAndZipArray = cityAndZip.split(",");


                if (cityAndZipArray.length != 2) {
                    System.err.println("Invalid request from client. Please provide city and ZIP code.");
                    continue;
                }


                String city = cityAndZipArray[0];
                String zipCode = cityAndZipArray[1];


                // Generate weather forecast based on city
                String weatherForecast = generateWeatherForecast(city);


                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();
                byte[] sendData = weatherForecast.getBytes();
                DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);


                serverSocket.send(sendPacket); // Send weather forecast to client
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Method to generate a random weather forecast for the given city
    private static String generateWeatherForecast(String city) {
        if (weatherData.containsKey(city)) {
            String[] forecasts = weatherData.get(city);
            Random random = new Random();
            return forecasts[random.nextInt(forecasts.length)];
        } else {
            return "Unknown city. Please try again.";
        }
    }
}
