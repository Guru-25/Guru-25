import java.io.*;
import java.net.*;


public class WeatherForecastClient {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java WeatherForecastClient <server_hostname> <server_port>");
            return;
        }


        try {
            InetAddress serverHost = InetAddress.getByName(args[0]);
            int serverPort = Integer.parseInt(args[1]);
            Socket clientSocket = new Socket(serverHost, serverPort);


            // Create input and output streams
            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
            BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());


            // Prompt user to enter city and ZIP code
            System.out.print("Enter a city: ");
            String city = inFromUser.readLine();
            System.out.print("Enter ZIP code: ");
            String zipCode = inFromUser.readLine();


            // Send city and ZIP code to server
            outToServer.writeBytes(city + "," + zipCode + '\n');


            // Receive weather forecast from server
            String weatherForecast = inFromServer.readLine();


            // Display weather forecast
            System.out.println("Weather Forecast: " + weatherForecast);


            // Close connection
            clientSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
