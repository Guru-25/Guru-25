import java.io.*;
import java.net.*;
import java.util.*;


public class WeatherForecastServer {
    private static final Map<String, String[]> weatherData = new HashMap<>();


    static {
        // Initialize weather data for different cities
        weatherData.put("New York", new String[]{"Sunny", "Partly Cloudy", "Rainy", "Thunderstorms"});
        weatherData.put("Los Angeles", new String[]{"Sunny", "Clear", "Foggy", "Cloudy"});
        weatherData.put("Chicago", new String[]{"Snowy", "Cloudy", "Windy", "Partly Cloudy"});
        weatherData.put("Miami", new String[]{"Rainy", "Thunderstorms", "Partly Sunny", "Cloudy"});
    }


    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(9876); // Port for communication


            System.out.println("Weather Forecast Server is running...");


            while (true) {
                Socket clientSocket = serverSocket.accept(); // Accept client connection
                WeatherThread thread = new WeatherThread(clientSocket);
                thread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    // Method to generate a random weather forecast for the given city
    private static String generateWeatherForecast(String city) {
        if (weatherData.containsKey(city)) {
            String[] forecasts = weatherData.get(city);
            Random random = new Random();
            return forecasts[random.nextInt(forecasts.length)];
        } else {
            return "Unknown city. Please try again.";
        }
    }


    static class WeatherThread extends Thread {
        Socket clientSocket;


        WeatherThread(Socket cs) {
            clientSocket = cs;
        }


        public void run() {
            try {
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                DataOutputStream outToClient = new DataOutputStream(clientSocket.getOutputStream());


                // Receive city and ZIP code request from client
                String cityAndZip = inFromClient.readLine();
                String[] cityAndZipArray = cityAndZip.split(",");


                if (cityAndZipArray.length != 2) {
                    outToClient.writeBytes("Invalid request. Please provide city and ZIP code.\n");
                    clientSocket.close();
                    return;
                }


                String city = cityAndZipArray[0];
                String zipCode = cityAndZipArray[1];


                // Generate weather forecast based on city
                String weatherForecast = generateWeatherForecast(city);


                // Send weather forecast to client
                outToClient.writeBytes(weatherForecast + '\n');


                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
