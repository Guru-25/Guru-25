import java.net.*;

class SummationClient {

    public static void main(String[] args) {

        try {
            InetAddress serverHost = InetAddress.getByName(args[0]);
            int serverPort = Integer.parseInt(args[1]);
            int count = Integer.parseInt(args[2]);

            DatagramSocket clientSocket = new DatagramSocket();

            byte[] sendData = Integer.toString(count).getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverHost, serverPort);
            clientSocket.send(sendPacket);

            byte[] receiveData = new byte[1024];
            DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
            clientSocket.receive(receivePacket);
            String sumString = new String(receivePacket.getData(), 0, receivePacket.getLength());
            int sum = Integer.parseInt(sumString);

            System.out.println("Sum = " + sum);

            clientSocket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}