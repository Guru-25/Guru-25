import java.net.*;

class SummationThread extends Thread {

    private DatagramSocket socket;
    private InetAddress clientAddress;
    private int clientPort;
    private int count;

    public SummationThread(DatagramSocket socket, InetAddress clientAddress, int clientPort, int count) {
        this.socket = socket;
        this.clientAddress = clientAddress;
        this.clientPort = clientPort;
        this.count = count;
    }

    public void run() {
        try {
            int sum = 0;
            for (int ctr = 1; ctr <= count; ctr++) {
                sum += ctr;
                Thread.sleep(200);
            }

            String sumString = Integer.toString(sum);
            byte[] sendData = sumString.getBytes();

            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            socket.send(sendPacket);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}