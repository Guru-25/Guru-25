import java.net.*;
import java.io.*;

class servertcp {
    public static void main(String[] args) {
        ServerSocket ss = null;
        PrintWriter out = null;
        BufferedReader in = null;
        Socket client = null;

        try {
            ss = new ServerSocket(12345);
            System.out.println("Server is running...");
            client = ss.accept();
            System.out.println("Client connected: " + client);
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String read;
            while ((read = in.readLine()) != null) {
                System.out.println("Client says: " + read);
                String reply = reader.readLine();
                out.println(reply);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null)
                    out.close();
                if (in != null)
                    in.close();
                if (client != null)
                    client.close();
                if (ss != null)
                    ss.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
