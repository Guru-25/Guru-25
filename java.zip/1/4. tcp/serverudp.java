//serverudp
import java.io.*;
import java.net.*;
class serverudp{
    public static void main(String arg[]){
        DatagramSocket socket=null;
        try{
            socket=new DatagramSocket(12345);
            System.out.println("Server is running...");
            while(true){
                byte []  receive=new byte[1024];
                byte [] send=new byte[1024];
                DatagramPacket rev=new DatagramPacket(receive,receive.length);
                socket.receive(rev);
                InetAddress cid=rev.getAddress();
                int port= rev.getPort();
                String mes=new String(rev.getData()).trim();
                System.out.println("The client says :" + mes);
                BufferedReader reader=new BufferedReader(new InputStreamReader(System.in)); 
                String m= reader.readLine();
                send=m.getBytes();
                DatagramPacket se=new DatagramPacket(send,send.length,cid,port);
                socket.send(se);
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        finally{
            if (socket!=null){
                socket.close();
            }
        }
    }
}
