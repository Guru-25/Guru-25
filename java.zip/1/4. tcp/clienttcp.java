import java.net.*;
import java.io.*;

class clienttcp {
    public static void main(String[] args) {
        Socket client = null;
        PrintWriter out = null;
        BufferedReader in = null;

        try {
            client = new Socket("localhost", 12345);
            System.out.println("Client is running...");
            System.out.println("Client connected: " + client);
            out = new PrintWriter(client.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            String userMessage;
            String serverResponse;
            while ((userMessage = reader.readLine()) != null) {
                out.println(userMessage);
                serverResponse = in.readLine();
                System.out.println("Server says: " + serverResponse);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null)
                    out.close();
                if (in != null)
                    in.close();
                if (client != null)
                    client.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
