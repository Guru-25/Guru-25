import java.io.Serializable;
public class Customer implements Serializable {
String name;
String address;
double phoneNumber;
int amount; // Added amount field
int points; // Added points field
public Customer(String name, String address, double phoneNumber) {
this.name = name;
this.address = address;
this.phoneNumber = phoneNumber;
}
// Added input method
public void input(int amount) {
this.amount = amount;
}
// Added points_calculation method
public void points_calculation() {
	// points calculation logic here
this.points = amount * 10; // Just a sample calculation
}
@Override
public String toString() {
return "Name: " + name + ", Address: " + address + ", Phone Number: " + phoneNumber + ",
Points: " + points;
}
}