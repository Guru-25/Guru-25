import java.io.*;
import java.net.*;
public class Client {
public static void main(String[] args) {
Socket socket = null;
ObjectOutputStream oos = null;
ObjectInputStream ois = null;
try {
InetAddress serverAddress = InetAddress.getByName("localhost");
int serverPort = 12345;
// Connect to the server
socket = new Socket(serverAddress, serverPort);
System.out.println("Client is running...");
// Create object streams for sending and receiving objects
oos = new ObjectOutputStream(socket.getOutputStream());
ois = new ObjectInputStream(socket.getInputStream());
BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
while (true) {
System.out.println("Enter customer details:");
System.out.print("Name: ");
String name = reader.readLine();
System.out.print("Address: ");
String address = reader.readLine();
System.out.print("Phone Number: ");
double phoneNumber = Double.parseDouble(reader.readLine());
System.out.print("Enter the amount: ");
int amount = Integer.parseInt(reader.readLine());
// Create a Customer object with the provided details
Customer customer = new Customer(name, address, phoneNumber);
customer.input(amount);
// Send the Customer object to the server
oos.writeObject(customer);
oos.flush();
// Receive response from the server
String replyMessage = (String) ois.readObject();
System.out.println("Server says: " + replyMessage);
}
} catch (IOException | ClassNotFoundException e) {
e.printStackTrace();
} finally {
try {
if (ois != null) ois.close();
if (oos != null) oos.close();
if (socket != null) socket.close();
} catch (IOException e) {
e.printStackTrace();
}
}
}
}