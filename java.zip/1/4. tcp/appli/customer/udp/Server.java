import java.io.*;
import java.net.*;
public class Server {
	public static void main(String[] args) {
ServerSocket serverSocket = null;
try {
serverSocket = new ServerSocket(12345);
System.out.println("Server is running...");
while (true) {
// Accept incoming client connection
Socket clientSocket = serverSocket.accept();
System.out.println("Client connected: " +
clientSocket.getInetAddress().getHostAddress());
// Create object streams for sending and receiving objects
ObjectInputStream ois = new ObjectInputStream(clientSocket.getInputStream());
ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
while (true) {
// Receive Customer object from the client
Customer customer = (Customer) ois.readObject();
System.out.println("Received from client: " + customer.toString());
// Process the received customer data (here, just echoing back)
String replyMessage = customer.toString();
oos.writeObject(replyMessage);
oos.flush();
}
}
} catch (IOException | ClassNotFoundException e) {
e.printStackTrace();
} finally {
try {
if (serverSocket != null) serverSocket.close();
} catch (IOException e) {
e.printStackTrace();
}
}
}
}