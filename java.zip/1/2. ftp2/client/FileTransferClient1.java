import java.io.*;
import java.net.*;

public class FileTransferClient1 {
    private static final int SERVER_PORT = 12345;
    private static final int BUFFER_SIZE = 1024;

    public static void main(String[] args) {
        try {
            DatagramSocket clientSocket = new DatagramSocket(); // Create UDP socket

            BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));

            System.out.println("Connected to server.");

            displayMenu(); // Display menu options

            String choice = inFromUser.readLine();

            InetAddress serverAddress = InetAddress.getByName("localhost");
            byte[] sendData = choice.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, SERVER_PORT);
            clientSocket.send(sendPacket);

            switch (choice) {
                case "1":
                    System.out.print("Enter file name to send: ");
                    String sendFileName = inFromUser.readLine();
                    sendFile(clientSocket, serverAddress, sendFileName);
                    break;
                case "2":
                    System.out.print("Enter file name to receive: ");
                    String receiveFileName = inFromUser.readLine();
                    receiveFile(clientSocket, serverAddress, receiveFileName);
                    break;
                default:
                    System.out.println("Invalid choice. Closing connection.");
                    break;
            }

            clientSocket.close(); // Close connection
            System.out.println("Connection closed.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Send a file to the server");
        System.out.println("2. Receive a file from the server");
        System.out.print("Enter your choice: ");
    }

    private static void sendFile(DatagramSocket clientSocket, InetAddress serverAddress, String fileName) throws IOException {
        File fileToSend = new File(fileName);
        if (!fileToSend.exists()) {
            System.out.println("File does not exist.");
            return;
        }

        FileInputStream fileInputStream = new FileInputStream(fileToSend);

        byte[] buffer = new byte[BUFFER_SIZE];
        // DatagramPacket sendPacket = new DatagramPacket(buffer, bytesRead, serverAddress, SERVER_PORT);
        //     clientSocket.send(sendPacket);
        int bytesRead;
        while ((bytesRead = fileInputStream.read(buffer)) != -1) {
            DatagramPacket sendPacket = new DatagramPacket(buffer, bytesRead, serverAddress, SERVER_PORT);
            clientSocket.send(sendPacket);
        }

        fileInputStream.close();
        System.out.println("File sent successfully.");
    }

    private static void receiveFile(DatagramSocket clientSocket, InetAddress serverAddress, String fileName) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(fileName);

        byte[] buffer = new byte[BUFFER_SIZE];
        DatagramPacket receivePacket = new DatagramPacket(buffer, buffer.length);
        clientSocket.receive(receivePacket);

        while (receivePacket.getLength() > 0) {
            fileOutputStream.write(buffer, 0, receivePacket.getLength());
            clientSocket.receive(receivePacket);
        }

        fileOutputStream.close();
        System.out.println("File received successfully.");
    }
}