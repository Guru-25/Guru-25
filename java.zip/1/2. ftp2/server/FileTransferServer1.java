import java.io.*;
import java.net.*;

public class FileTransferServer1 {
    private static final int SERVER_PORT = 12345;
    private static final int BUFFER_SIZE = 1024;

    public static void main(String[] args) {
        try {
            DatagramSocket serverSocket = new DatagramSocket(SERVER_PORT); // Server socket listening on port 12345

            System.out.println("Server started. Waiting for clients...");

            while (true) {
                byte[] receiveData = new byte[BUFFER_SIZE];
                DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

                serverSocket.receive(receivePacket); // Receive incoming packet
                InetAddress clientAddress = receivePacket.getAddress();
                int clientPort = receivePacket.getPort();

                String clientMessage = new String(receivePacket.getData(), 0, receivePacket.getLength()); // Extract client's choice

                if (clientMessage.equals("1")) {
                    receiveFile(serverSocket, clientAddress, clientPort);
                } else if (clientMessage.equals("2")) {
                    sendFile(serverSocket, clientAddress, clientPort);
                } else {
                    System.out.println("Invalid choice. Closing connection.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void receiveFile(DatagramSocket serverSocket, InetAddress clientAddress, int clientPort) throws IOException {
        byte[] receiveData = new byte[BUFFER_SIZE];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        serverSocket.receive(receivePacket); // Receive file name from client
        String fileName = new String(receivePacket.getData(), 0, receivePacket.getLength());

        System.out.println("Receiving file: " + fileName);

        FileOutputStream fileOutputStream = new FileOutputStream(fileName);

        while (true) {
            serverSocket.receive(receivePacket); // Receive file data
            if (new String(receivePacket.getData(), 0, receivePacket.getLength()).equals("EOF")) {
                break; // End of file
            }
            fileOutputStream.write(receivePacket.getData(), 0, receivePacket.getLength());
        }

        fileOutputStream.close();
        System.out.println("File received successfully.");
    }

    private static void sendFile(DatagramSocket serverSocket, InetAddress clientAddress, int clientPort) throws IOException {
        byte[] receiveData = new byte[BUFFER_SIZE];
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);

        serverSocket.receive(receivePacket); // Receive file name from client
        String fileName = new String(receivePacket.getData(), 0, receivePacket.getLength());
        File fileToSend = new File(fileName);

        if (!fileToSend.exists()) {
            System.out.println("File does not exist.");
            byte[] sendData = "File not found".getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, clientAddress, clientPort);
            serverSocket.send(sendPacket);
            return;
        }

        System.out.println("Sending file: " + fileName);

        FileInputStream fileInputStream = new FileInputStream(fileToSend);

        byte[] sendData = new byte[BUFFER_SIZE];
        int bytesRead;

        while ((bytesRead = fileInputStream.read(sendData)) != -1) {
            DatagramPacket sendPacket = new DatagramPacket(sendData, bytesRead, clientAddress, clientPort);
            serverSocket.send(sendPacket);
        }

        // Send EOF to indicate end of file
        byte[] eofData = "EOF".getBytes();
        DatagramPacket eofPacket = new DatagramPacket(eofData, eofData.length, clientAddress, clientPort);
        serverSocket.send(eofPacket);

        fileInputStream.close();
        System.out.println("File sent successfully.");
    }
}